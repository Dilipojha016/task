



function twoSum(nums, target) {
  const numToIndex = {};
  for (let index = 0; index < nums.length; index++) {
      const num = nums[index];
      const complement = target - num;
      if (numToIndex.hasOwnProperty(complement)) {
        return [numToIndex[complement], index];
      }
      numToIndex[num] = index;
  }
  return [];
}


console.log(twoSum([15, 7, 2,11,4],9))
console.log(twoSum([3,2,5, 4],6))
console.log(twoSum([3,1,3],6))
