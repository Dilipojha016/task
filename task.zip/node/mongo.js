
//Query here
[
  {
    "$unwind": "$items"
  },
  {
    "$addFields": {
      "month": {
        "$dateToString": {
          "format": "%Y-%m",
          "date": "$date"
        }
      },
      "itemRevenue": {
        "$multiply": ["$items.quantity", "$items.price"]
      }
    }
  },
  {
    "$group": {
      "_id": {
        "store": "$store",
        "month": "$month"
      },
      "totalRevenue": {
        "$sum": "$itemRevenue"
      },
      "averagePrice": {
        "$avg": "$items.price"
      }
    }
  },
  {
    "$project": {
      "_id": 0,
      "store": "$_id.store",
      "month": "$_id.month",
      "totalRevenue": 1,
      "averagePrice": 1
    }
  },
  {
    "$sort": {
      "store": 1,
      "month": 1
    }
   }
 ]


// // Explanation of the Pipeline
// // $unwind: Deconstructs the items array so each item becomes a separate document.
// // $addFields:
// // month: Extracts the month in the "YYYY-MM" format from the date field.
// // itemRevenue: Calculates the revenue for each item by multiplying the quantity by the price.
// // $group:
// // _id: Groups documents by store and month.
// // totalRevenue: Sums up the itemRevenue for each group.
// // averagePrice: Calculates the average price of items for each group.
// // $project: Reshapes the documents to include only the store, month, totalRevenue, and averagePrice fields, and removes the _id field.
// // $sort: Sorts the results first by store in ascending order and then by month in ascending order.

// Assume you have the following documents in your collection:


// [
//   {
//     "_id": ObjectId("..."),
//     "date": ISODate("2024-06-15T00:00:00Z"),
//     "store": "Store A",
//     "items": [
//       {
//         "name": "item1",
//         "quantity": 5,
//         "price": 10.0
//       },
//       {
//         "name": "item2",
//         "quantity": 3,
//         "price": 20.0
//       }
//     ]
//   },
//   {
//     "_id": ObjectId("..."),
//     "date": ISODate("2024-06-20T00:00:00Z"),
//     "store": "Store B",
//     "items": [
//       {
//         "name": "item3",
//         "quantity": 4,
//         "price": 15.0
//       },
//       {
//         "name": "item4",
//         "quantity": 2,
//         "price": 30.0
//       }
//     ]
//   }
// ]
